<?php

 if($_SERVER['REQUEST_METHOD']=='POST'){
 
 $image = $_POST['image'];
 $name = $_POST['name'];
 $email = $_POST['email'];

 require_once('dbConnect.php');
 
 $sql ="SELECT user_id FROM registered_users WHERE useremail= '$email'";
 
 $res = mysqli_query($con,$sql);
 
 $id = 0;
 
 while($row = mysqli_fetch_array($res)){
 $id = $row['user_id'];
 }
 
 $path = "uploads/$id.png";
 
 $actualpath = "http://www.viesr.com/profile/$path";
 
 $sql = "UPDATE registered_users SET username = '$name' , profile_image ='$actualpath' WHERE useremail= '$email'";
 
 if(mysqli_query($con,$sql)){
 echo "Successfully Uploaded";
 }
 
 mysqli_close($con);
 }else{
 echo "Error";
 }
