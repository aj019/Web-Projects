	
<?php 
 
 define('HOST','198.71.225.65');
 define('USER','kushan22');
 define('PASS','Ronaldo7');
 define('DB','certificateApp_');
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect to db');