<html>
<head>
	<style>
		.col{
			font-size: 24px;			
		}
	</style>
</head>
<body>

</body>
</html>
<?php
	echo "<div class='col'>Hello</div>";
?>
