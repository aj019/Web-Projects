<head>
	<style type="text/css">
		div{
			font-size: 25px;
		}
		.line{
			color: red;
		}
	</style>
</head>
<?php
	echo "<div class='line'>First Script</div>";
	echo "Hello&nbsp;World";
?>

<div>Hello</div>
