Human = {name:"Praveer",
	Age:'21',
	 Branch:'CSE'
	}
//alert(Human.name);
alert(Human.name);
