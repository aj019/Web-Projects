<?php
	echo $_SERVER['PHP_SELF'];
	echo "<br>";
	print_r($_SERVER);
?>