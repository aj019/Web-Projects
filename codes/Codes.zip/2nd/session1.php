<?php
	session_start();
	$_SESSION['userid'] = 12;
	echo $_SESSION['userid'];

?>
