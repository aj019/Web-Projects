<?php

	$conn=new mysqli('localhost','anuj96540','9654018751','webscraper');

	if(!$conn){

		die("Connection error:".mysqli_connect_error());
	}

?>